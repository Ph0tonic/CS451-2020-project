package cs451.utils;

public interface Logger {
    void log(String log);

    void dump();
}
