package cs451.broadcast;

public interface FifoMultiplexedBroadcastReceive {
    void deliver(int originId, int messageId);
}
