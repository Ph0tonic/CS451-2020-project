package cs451.broadcast;

public interface FifoBroadcastReceive {
    void deliver(int originId, byte[] data);
}
